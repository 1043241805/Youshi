//
//  HomepageCellModel.swift
//  youshi
//
//  Created by HuamuIOS on 2018/6/13.
//  Copyright © 2018年 Dingyouyou. All rights reserved.
//

import UIKit

class HomepageCellModel: NSObject {
    var image : String?
    var text : String?
    var imgHeight : CGFloat! {
        get {
            if image != nil {
              return (kScreenWidth - 20) / 2
            }
            return 0.0
        }
    }
    
    var textHegiht : CGFloat! {
        get {
            if text != nil {
               return text?.sizeTwoLine()
            }
            return 0.0
        }
    }
    
    var cellHeight : CGFloat! {
        get {
            if image == nil && text == nil {
              return 0.0
            }
            return imgHeight + textHegiht + CGFloat(88.0)
        }
    }
}

extension String {
    func sizeTwoLine() -> CGFloat {
        let font = UIFont.systemFont(ofSize: 12)
        let rect = NSString.init(string: self).boundingRect(with: CGSize(width : kScreenWidth - 20, height : 30), options: .usesLineFragmentOrigin, attributes: [NSAttributedStringKey.font: font], context: nil)
        return rect.height
    }
}
