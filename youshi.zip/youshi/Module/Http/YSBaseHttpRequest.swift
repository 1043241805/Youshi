//
//  YSBaseHttpRequest.swift
//  youshi
//
//  Created by HuamuIOS on 2018/6/13.
//  Copyright © 2018年 Dingyouyou. All rights reserved.
//

import UIKit
import Alamofire
typealias FinisishBlock = (Data,Bool) -> ()

class YSBaseHttpRequest: NSObject {
    static let sharedRequest = YSBaseHttpRequest()
    override init() {
        
    }
    
    func ys_request(method : HTTPMethod,
                    url : URLConvertible,
                    parameter : [String : Any],
                    finishBlock : @escaping FinisishBlock) {
          let requestHeader:HTTPHeaders = ["Content-Type":"application/x-www-form-urlencoded"]
          Alamofire.request(url, method: method, parameters: parameter, encoding: URLEncoding.default, headers: requestHeader).responseData(completionHandler : {(dataResponse) in
                    switch dataResponse.result {
                        case .success(let value) : //请求成功
                          finishBlock(value,true)
                        case .failure(let error) : //请求失败
                          NSLog("http error : \(error) url : \(url)")
                          finishBlock(Data(),false)
                        break
                    }
         })
    }
    
}
