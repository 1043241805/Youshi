//
//  YSUIConst.swift
//  youshi
//
//  Created by HuamuIOS on 2018/6/13.
//  Copyright © 2018年 Dingyouyou. All rights reserved.
//

import UIKit
//屏幕宽度
let kScreenWidth : CGFloat = UIScreen.main.bounds.width
//屏幕高度
let kScreenHeight : CGFloat = UIScreen.main.bounds.height

let kZero : CGFloat = 0

//适配X的导航栏高度
func k_iPhone_X_NavHeight() -> CGFloat {
    if kScreenHeight >= 812 {
        return 83
    } else {
        return 64
    }
}

class YSUIConst: NSObject {
    

}
