//
//  HomepageHttpRequest.swift
//  youshi
//
//  Created by HuamuIOS on 2018/6/13.
//  Copyright © 2018年 Dingyouyou. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
typealias HomepageFinisishBlock = (Array<HomepageCellModel>) -> ()
class HomepageHttpRequest: NSObject {
    fileprivate let urlStr = "http://static.youshikoudai.com/mockapi/data"
    func getHompeData(finishBlock :@escaping HomepageFinisishBlock) {
        var arr = Array<HomepageCellModel>()
        let ht = YSBaseHttpRequest.init()
        ht.ys_request(method: .get, url: urlStr, parameter: [String : Any]()) { (dataReponse, isSuccess) in
            if isSuccess {
                let json = JSON(dataReponse).arrayValue
                if json.count > 0 {
                    for subDict in json {
                        let model = HomepageCellModel()
                        model.image = subDict["image"].stringValue
                        model.text = subDict["text"].stringValue
                        arr.append(model)
                    }
                }
               finishBlock(arr)
            } else {
                finishBlock(Array<HomepageCellModel>())
            }
        }
    }

}
