//
//  HomePageViewController.swift
//  youshi
//
//  Created by HuamuIOS on 2018/6/13.
//  Copyright © 2018年 Dingyouyou. All rights reserved.
//

import UIKit

class HomePageViewController: YSBaseViewController {

    private var dataArray : Array<HomepageCellModel>!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "首页"
        dataArray = Array<HomepageCellModel>()
        self.view.addSubview(self.tableView)
        let nib = UINib(nibName : "HomepageTableViewCell" , bundle : nil)
        self.tableView.register(nib , forCellReuseIdentifier: "HomepageTableViewCellID")
        getData()
    }
    
    func getData() {
        let hm = HomepageHttpRequest()
        weak var weakSelf = self
        hm.getHompeData { (dataArray) in
            weakSelf?.dataArray = dataArray
            weakSelf?.tableView.reloadData()
        }

    }
    
    //MARK: -TABLEVIEW
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataArray.count
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return dataArray[indexPath.row].cellHeight
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HomepageTableViewCellID", for: indexPath) as! HomepageTableViewCell
        if indexPath.row < dataArray.count {
            cell.model = dataArray[indexPath.row]
        }
        return cell
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
