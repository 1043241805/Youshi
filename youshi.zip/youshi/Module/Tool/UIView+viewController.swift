//
//  UIView+viewController.swift
//  HuamuFinance
//
//  Created by HuamuIOS on 2018/4/20.
//  Copyright © 2018年 Dingyouyou. All rights reserved.
//

import UIKit

class UIView_viewController: UIView {


}





extension UIView {
    
    func getCurrentWindow() -> UIWindow? {
        var window: UIWindow? = UIApplication.shared.keyWindow
        
        if window?.windowLevel != UIWindowLevelNormal {
            
            for tempWindow in UIApplication.shared.windows {
                
                if tempWindow.windowLevel == UIWindowLevelNormal {
                    
                    window = tempWindow
                    break
                }
            }
            
        }
        
        return window
    }
    
//    func parentViewController() -> UIViewController? {
//        // 1.声明UIViewController类型的指针
//               var viewController: UIViewController?
//      
//              // 2.找到当前显示的UIWindow
//               let window: UIWindow? = self.getCurrentWindow()
//      
//               // 3.获得当前显示的UIWindow展示在最上面的view
//             let frontView = window?.subviews.first
//      
//             // 4.找到这个view的nextResponder
//            let nextResponder = frontView?.next
//        
//   
//       if nextResponder?.isKind(of: UIViewController.classForCoder()) == true {
//            viewController = nextResponder as? UIViewController
//            if viewController?.isKind(of: UITabBarController.classForCoder()) == true {
//                let vc = viewController as! MainTabBarViewController
//                dPrint(item: "\(vc.selectedViewController)")
//                return vc.selectedViewController
//            }
//        } else {
//            viewController = window?.rootViewController
//        }
//        return viewController
//    }
    
    
    
    func topViewController() -> UIViewController? {
        
        return self.topViewControllerWithRootViewController(viewController: self.getCurrentWindow()?.rootViewController)
    }
    
    func topViewControllerWithRootViewController(viewController :UIViewController?) -> UIViewController? {
        
        if viewController == nil {
            
            return nil
        }
        
        if viewController?.presentedViewController != nil {
            
            return self.topViewControllerWithRootViewController(viewController: viewController?.presentedViewController!)
        }
        else if viewController?.isKind(of: UITabBarController.self) == true {
            
            return self.topViewControllerWithRootViewController(viewController: (viewController as! UITabBarController).selectedViewController)
        }
        else if viewController?.isKind(of: UINavigationController.self) == true {
            
            return self.topViewControllerWithRootViewController(viewController: (viewController as! UINavigationController).visibleViewController)
        }
        else {
            return viewController
        }
    }

}



