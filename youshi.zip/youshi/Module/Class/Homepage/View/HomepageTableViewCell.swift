//
//  HomepageTableViewCell.swift
//  youshi
//
//  Created by HuamuIOS on 2018/6/13.
//  Copyright © 2018年 Dingyouyou. All rights reserved.
//

import UIKit
import SDWebImage

class HomepageTableViewCell: UITableViewCell {
    //MARK: -
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var imgViewHeight: NSLayoutConstraint!
    @IBAction func AButtonClicl(_ sender: Any) {
        let aVC = AViewController()
        topViewController()?.navigationController?.pushViewController(aVC, animated: true)
    }
    
    @IBAction func BButtonClick(_ sender: Any) {
        let bVC = BViewController()
        topViewController()?.navigationController?.pushViewController(bVC, animated: true)
        
    }
    
    @IBOutlet weak var contentTextLabel: UILabel!
    
    var model : HomepageCellModel! {
        willSet {
            imgView.sd_setImage(with:  URL.init(string: newValue.image!)) { (image, error, type, url) in
                
            }
            imgViewHeight.constant = newValue.imgHeight
            contentTextLabel.text = newValue.text
        }
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.selectionStyle = .none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
